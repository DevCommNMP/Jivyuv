import React from "react";
import Privacy from "../../components/Privacy";

const PrivacyPolicy = () => {
  return (
    <Privacy />
  );
};

export default PrivacyPolicy;