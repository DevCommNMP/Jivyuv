import React from "react";
import Terms from "../../components/Terms";

const TermsAndServices = () => {
  return (
    <Terms></Terms>
  );
};

export default TermsAndServices;
