import SignupForm from "../../../components/SignupForm";

export default function SignupPage() {
  return (
    <>
      <SignupForm />
    </>
  );
}
